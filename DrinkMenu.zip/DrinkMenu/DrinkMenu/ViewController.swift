//
//  ViewController.swift
//  DrinkMenu
//
//  Created by Fariha Hussain on 8/31/20.
//  Copyright © 2020 VenPro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    
    @IBAction func Margarita(_ sender: Any) {
    }
    
    @IBAction func Beer(_ sender: Any) {
    }
    
    @IBAction func Cosmo(_ sender: Any) {
    }
    
    @IBAction func Martini(_ sender: Any) {
    }
    
    @IBAction func Daiquiri(_ sender: Any) {
    }
    
    
    @IBAction func Whiskey(_ sender: Any) {
    }
    
    @IBAction func Coke(_ sender: Any) {
    }
    
    @IBAction func Sprite(_ sender: Any) {
    }
    
    @IBAction func MountainDew(_ sender: Any) {
    }
    
    @IBAction func DietCoke(_ sender: Any) {
    }
    
    @IBAction func Fanta(_ sender: Any) {
    }
        
    @IBAction func Water(_ sender: Any) {
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
}

